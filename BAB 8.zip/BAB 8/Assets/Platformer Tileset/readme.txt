Aekiro - Platformer Tileset

This a free sprite pack containing :
- 256x256 tileset
- 25 props
The sprites work out of the box with Unity.
You can use it for commercial projects, no attribution needed.

Included files are PNGs.


You can get the full bundle here:
http://u3d.as/26ku




